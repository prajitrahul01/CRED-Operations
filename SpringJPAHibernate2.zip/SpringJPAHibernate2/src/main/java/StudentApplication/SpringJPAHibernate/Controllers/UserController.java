package StudentApplication.SpringJPAHibernate.Controllers;

import StudentApplication.SpringJPAHibernate.Model.User;
import StudentApplication.SpringJPAHibernate.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserRepository userRepoObj;
    @PostMapping("/signup")
    public User save(@RequestBody User userObj){
        System.out.println(userObj);
        User userResponse = userRepoObj.save(userObj);

        return userResponse;
    };
    @GetMapping("/getall")
public List<User>save(){
        return userRepoObj.findAll();
    }


@GetMapping("/delall")
public void removeAllCourses(){
    userRepoObj.deleteAll();
}
//

    @GetMapping("/deletebyid/{id}")
    public void deleteByUserId(@PathVariable("id") int id){
        userRepoObj.deleteById(id);
    }

    @GetMapping("/isuser/{id}")
    public String isUserExist(@PathVariable("id") int id){
        if(userRepoObj.existsById(id))
            return "Id exist";
        else
            return "Id doesn't exist";
    }
@GetMapping("/findbyid/{id}")
    public User findByUserId(@PathVariable int id){
        // Optional class for null pointer exception
    Optional<User> tempObj = userRepoObj.findById(id);
    if(tempObj.isEmpty()){
        System.out.println("User id is not found" + id);
    }
    return userRepoObj.findById(id).get();
}



}

